// jQuery UI Accordion voor veelgestelde vragen op de tarievenpagina.
// Het contactformulier is bewust niet gekoppeld aan een backend (toegestaan volgens de opdracht).
$(function () {
    if ($("#faq-accordion").length && $.fn.accordion) {
        $("#faq-accordion").accordion({collapsible: true, active: false, heightStyle: "content"});
    }
});
