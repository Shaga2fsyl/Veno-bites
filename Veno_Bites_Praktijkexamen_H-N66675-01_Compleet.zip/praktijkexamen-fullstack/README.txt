NHA Praktijkexamen Full Stack Developer (H-N66675-01)
Project: Veno Bites

Start: open index.html in een browser.
De website bevat vier pagina's, CSS mediaqueries voor mobiel en desktop, werkende interne navigatie en een demonstratiecontactformulier.
Tarieven gebruikt jQuery 3.7.1 en jQuery UI 1.14.1 via CDN; een internetverbinding is nodig voor de Accordion.

De oorspronkelijke productfoto's staan in afbeeldingen/. De labels met persoonlijke telefoonnummers zijn niet opgenomen.
De prijzen zijn demonstratieprijzen.
Het Worddocument staat in documenten/.

GitHub: https://github.com/Shaga2fsyl/Veno-bites
Publicatie via GitHub Pages moet nog handmatig worden geactiveerd onder Settings > Pages > Deploy from a branch > main > /(root).

Bestaande PythonAnywhere-cursuswebsite: https://shaga2fsyl.pythonanywhere.com (ander project).
